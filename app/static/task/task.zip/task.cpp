#include <iostream>

void _xor(char x)
{
    char arr[] = {0x5c,0x6a,0x70,0x25,0x64,0x77,0x60,0x25,0x67,0x77,0x60,0x64,0x71,0x6d,0x71,0x64,0x6e,0x6c,0x6b,0x62,0x29,0x25,0x4d,0x64,0x66,0x6e,0x60,0x77,0x68,0x64,0x6b,0x24};

    for (unsigned int i = 0; i < sizeof(arr); ++i)
    {
        printf("%02hx ", arr[i] ^ x);
    }
}

int main(int argc, char const *argv[])
{
    std::cout << "Hello! My name is Passwordgiver. What is you name?" << std::endl;

    std::string name;
    std::cin >> name;

    if (name != "Pryanya")
    {
        std::cout << "Unfortunately, acced denied!" << std::endl;
        system("pause");
        return 0;
    }

    std::cout << "Ya, this is really you! Then i give you the password, like i promise!" << std::endl;
    _xor(5);
    std::cout << "\nBut it is encoded to HEX! Use Cyberchef to decode it!" << std::endl;

    system("pause");

    return 0;
}